import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Clock, Truck, Shield, Headphones } from 'lucide-react';
import ProductCard from '../components/ProductCard';

const Homepage = () => {
  // Mock data for products
  const featuredProducts = [
    {
      id: '1',
      name: 'Samsung Galaxy S24 Ultra 5G (Titanium Gray, 256GB)',
      price: 124999,
      originalPrice: 139999,
      discount: 11,
      rating: 4.5,
      reviews: 12453,
      image: 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg',
      category: 'electronics',
    },
    {
      id: '2',
      name: 'Apple MacBook Air M2 Chip 13.6-inch (8GB/256GB SSD)',
      price: 99999,
      originalPrice: 119900,
      discount: 17,
      rating: 4.7,
      reviews: 8234,
      image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg',
      category: 'electronics',
    },
    {
      id: '3',
      name: 'Nike Air Force 1 \'07 Sneakers',
      price: 7495,
      originalPrice: 8295,
      discount: 10,
      rating: 4.3,
      reviews: 2341,
      image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg',
      category: 'fashion',
    },
    {
      id: '4',
      name: 'Levi\'s 511 Slim Fit Jeans',
      price: 2799,
      originalPrice: 3499,
      discount: 20,
      rating: 4.2,
      reviews: 5672,
      image: 'https://images.pexels.com/photos/1598507/pexels-photo-1598507.jpeg',
      category: 'fashion',
    },
  ];

  const groceryProducts = [
    {
      id: '5',
      name: 'Fresh Organic Bananas (1 KG)',
      price: 45,
      originalPrice: 55,
      discount: 18,
      rating: 4.1,
      reviews: 234,
      image: 'https://images.pexels.com/photos/2872755/pexels-photo-2872755.jpeg',
      category: 'grocery',
      isInstantDelivery: true,
      deliveryTime: '15 mins',
    },
    {
      id: '6',
      name: 'Amul Fresh Milk (1 Litre)',
      price: 56,
      originalPrice: 60,
      discount: 7,
      rating: 4.4,
      reviews: 1234,
      image: 'https://images.pexels.com/photos/416656/pexels-photo-416656.jpeg',
      category: 'grocery',
      isInstantDelivery: true,
      deliveryTime: '10 mins',
    },
    {
      id: '7',
      name: 'Maggi 2-Minute Noodles Masala (Pack of 12)',
      price: 144,
      originalPrice: 156,
      discount: 8,
      rating: 4.3,
      reviews: 567,
      image: 'https://images.pexels.com/photos/884600/pexels-photo-884600.jpeg',
      category: 'grocery',
      isInstantDelivery: true,
      deliveryTime: '20 mins',
    },
  ];

  const categories = [
    {
      name: 'Electronics',
      image: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg',
      path: '/category/electronics',
      items: '2M+ items',
    },
    {
      name: 'Fashion',
      image: 'https://images.pexels.com/photos/934063/pexels-photo-934063.jpeg',
      path: '/category/fashion',
      items: '5M+ items',
    },
    {
      name: 'Grocery',
      image: 'https://images.pexels.com/photos/1435904/pexels-photo-1435904.jpeg',
      path: '/category/grocery',
      items: '500K+ items',
    },
    {
      name: 'Instant Delivery',
      image: 'https://images.pexels.com/photos/4393021/pexels-photo-4393021.jpeg',
      path: '/category/instant',
      items: '50K+ items',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold mb-4">
                India's Best
                <span className="text-yellow-400"> Shopping </span>
                Destination
              </h1>
              <p className="text-xl mb-8 text-blue-100">
                Millions of products at unbeatable prices with instant delivery across India
              </p>
              <div className="flex space-x-4">
                <Link
                  to="/category/electronics"
                  className="bg-orange-500 hover:bg-orange-600 px-8 py-3 rounded-lg font-semibold transition-colors"
                >
                  Shop Electronics
                </Link>
                <Link
                  to="/category/instant"
                  className="border-2 border-white hover:bg-white hover:text-blue-600 px-8 py-3 rounded-lg font-semibold transition-colors"
                >
                  Instant Delivery
                </Link>
              </div>
            </div>
            <div className="hidden lg:block">
              <img
                src="https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg"
                alt="Shopping"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="flex items-center space-x-3">
              <div className="bg-green-100 p-3 rounded-full">
                <Truck className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold">Free Delivery</h3>
                <p className="text-sm text-gray-600">On orders above ₹499</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="bg-orange-100 p-3 rounded-full">
                <Clock className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <h3 className="font-semibold">Instant Delivery</h3>
                <p className="text-sm text-gray-600">In 10-30 minutes</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="bg-blue-100 p-3 rounded-full">
                <Shield className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold">Secure Payments</h3>
                <p className="text-sm text-gray-600">100% Protected</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="bg-purple-100 p-3 rounded-full">
                <Headphones className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h3 className="font-semibold">24/7 Support</h3>
                <p className="text-sm text-gray-600">Always here to help</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Shop by Category</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {categories.map((category) => (
              <Link
                key={category.name}
                to={category.path}
                className="group bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden"
              >
                <div className="relative">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-40 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <div className="text-center text-white">
                      <h3 className="text-xl font-semibold mb-1">{category.name}</h3>
                      <p className="text-sm">{category.items}</p>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Featured Products</h2>
            <Link
              to="/category/electronics"
              className="flex items-center text-blue-600 hover:text-blue-700 font-semibold"
            >
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Instant Delivery Section */}
      <section className="py-12 bg-orange-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Instant Delivery</h2>
              <p className="text-gray-600">Get your essentials delivered in minutes</p>
            </div>
            <Link
              to="/category/instant"
              className="flex items-center text-orange-600 hover:text-orange-700 font-semibold"
            >
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {groceryProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Homepage;