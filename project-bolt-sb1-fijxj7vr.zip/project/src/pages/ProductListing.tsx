import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Filter, SlidersHorizontal, Grid, List } from 'lucide-react';
import ProductCard from '../components/ProductCard';

const ProductListing = () => {
  const { category } = useParams<{ category: string }>();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState('popularity');
  const [filters, setFilters] = useState({
    priceRange: [0, 200000],
    brand: [],
    rating: 0,
    deliveryTime: 'all',
  });

  // Mock products data
  const products = [
    {
      id: '1',
      name: 'Samsung Galaxy S24 Ultra 5G (Titanium Gray, 256GB)',
      price: 124999,
      originalPrice: 139999,
      discount: 11,
      rating: 4.5,
      reviews: 12453,
      image: 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg',
      category: 'electronics',
      brand: 'Samsung',
    },
    {
      id: '2',
      name: 'Apple iPhone 15 Pro (Natural Titanium, 128GB)',
      price: 134900,
      originalPrice: 139900,
      discount: 4,
      rating: 4.7,
      reviews: 8934,
      image: 'https://images.pexels.com/photos/699122/pexels-photo-699122.jpeg',
      category: 'electronics',
      brand: 'Apple',
    },
    {
      id: '3',
      name: 'OnePlus 12 5G (Flowy Emerald, 256GB)',
      price: 64999,
      originalPrice: 69999,
      discount: 7,
      rating: 4.4,
      reviews: 5642,
      image: 'https://images.pexels.com/photos/163065/mobile-phone-android-apps-phone-163065.jpeg',
      category: 'electronics',
      brand: 'OnePlus',
    },
    {
      id: '4',
      name: 'MacBook Air M2 Chip (Midnight, 8GB RAM, 256GB SSD)',
      price: 99900,
      originalPrice: 119900,
      discount: 17,
      rating: 4.6,
      reviews: 3421,
      image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg',
      category: 'electronics',
      brand: 'Apple',
    },
    {
      id: '5',
      name: 'Dell XPS 13 Plus (Intel i7, 16GB RAM, 512GB SSD)',
      price: 154900,
      originalPrice: 164900,
      discount: 6,
      rating: 4.3,
      reviews: 1892,
      image: 'https://images.pexels.com/photos/812264/pexels-photo-812264.jpeg',
      category: 'electronics',
      brand: 'Dell',
    },
    {
      id: '6',
      name: 'Sony WH-1000XM5 Wireless Noise Canceling Headphones',
      price: 29990,
      originalPrice: 34990,
      discount: 14,
      rating: 4.8,
      reviews: 7654,
      image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg',
      category: 'electronics',
      brand: 'Sony',
    },
  ];

  const brands = ['Apple', 'Samsung', 'OnePlus', 'Dell', 'Sony', 'HP', 'Lenovo', 'Xiaomi'];

  const getCategoryTitle = (cat: string) => {
    const titles = {
      electronics: 'Electronics',
      fashion: 'Fashion',
      grocery: 'Grocery',
      instant: 'Instant Delivery',
    };
    return titles[cat as keyof typeof titles] || 'Products';
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            {getCategoryTitle(category || '')}
          </h1>
          <p className="text-gray-600">
            Showing {products.length} results
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Filters Sidebar */}
          <div className="lg:w-64 bg-white rounded-lg shadow-md p-6 h-fit">
            <div className="flex items-center space-x-2 mb-6">
              <Filter className="w-5 h-5" />
              <h2 className="text-lg font-semibold">Filters</h2>
            </div>

            {/* Price Range */}
            <div className="mb-6">
              <h3 className="font-medium mb-3">Price Range</h3>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input type="radio" name="price" className="mr-2" />
                  <span className="text-sm">Under ₹10,000</span>
                </label>
                <label className="flex items-center">
                  <input type="radio" name="price" className="mr-2" />
                  <span className="text-sm">₹10,000 - ₹50,000</span>
                </label>
                <label className="flex items-center">
                  <input type="radio" name="price" className="mr-2" />
                  <span className="text-sm">₹50,000 - ₹1,00,000</span>
                </label>
                <label className="flex items-center">
                  <input type="radio" name="price" className="mr-2" />
                  <span className="text-sm">Above ₹1,00,000</span>
                </label>
              </div>
            </div>

            {/* Brand */}
            <div className="mb-6">
              <h3 className="font-medium mb-3">Brand</h3>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {brands.map((brand) => (
                  <label key={brand} className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    <span className="text-sm">{brand}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Rating */}
            <div className="mb-6">
              <h3 className="font-medium mb-3">Customer Rating</h3>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input type="radio" name="rating" className="mr-2" />
                  <span className="text-sm">4★ & above</span>
                </label>
                <label className="flex items-center">
                  <input type="radio" name="rating" className="mr-2" />
                  <span className="text-sm">3★ & above</span>
                </label>
                <label className="flex items-center">
                  <input type="radio" name="rating" className="mr-2" />
                  <span className="text-sm">2★ & above</span>
                </label>
              </div>
            </div>

            {/* Delivery */}
            {category === 'instant' && (
              <div className="mb-6">
                <h3 className="font-medium mb-3">Delivery Time</h3>
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input type="radio" name="delivery" className="mr-2" />
                    <span className="text-sm">Within 15 mins</span>
                  </label>
                  <label className="flex items-center">
                    <input type="radio" name="delivery" className="mr-2" />
                    <span className="text-sm">Within 30 mins</span>
                  </label>
                  <label className="flex items-center">
                    <input type="radio" name="delivery" className="mr-2" />
                    <span className="text-sm">Within 1 hour</span>
                  </label>
                </div>
              </div>
            )}
          </div>

          {/* Products Section */}
          <div className="flex-1">
            {/* Sort and View Options */}
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-3 sm:space-y-0">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <SlidersHorizontal className="w-4 h-4" />
                    <span className="text-sm font-medium">Sort by:</span>
                  </div>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="border border-gray-300 rounded px-3 py-1 text-sm"
                  >
                    <option value="popularity">Popularity</option>
                    <option value="price-low">Price - Low to High</option>
                    <option value="price-high">Price - High to Low</option>
                    <option value="discount">Discount</option>
                    <option value="newest">Newest</option>
                    <option value="rating">Rating</option>
                  </select>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-2 rounded ${
                      viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-600'
                    }`}
                  >
                    <Grid className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-2 rounded ${
                      viewMode === 'list' ? 'bg-blue-100 text-blue-600' : 'text-gray-600'
                    }`}
                  >
                    <List className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Products Grid */}
            <div className={`grid gap-6 ${
              viewMode === 'grid' 
                ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3' 
                : 'grid-cols-1'
            }`}>
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>

            {/* Pagination */}
            <div className="flex justify-center mt-12">
              <nav className="flex space-x-2">
                <button className="px-3 py-2 border border-gray-300 rounded text-gray-500">
                  Previous
                </button>
                <button className="px-3 py-2 bg-blue-600 text-white rounded">1</button>
                <button className="px-3 py-2 border border-gray-300 rounded text-gray-700 hover:bg-gray-50">
                  2
                </button>
                <button className="px-3 py-2 border border-gray-300 rounded text-gray-700 hover:bg-gray-50">
                  3
                </button>
                <button className="px-3 py-2 border border-gray-300 rounded text-gray-700 hover:bg-gray-50">
                  Next
                </button>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductListing;