import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Star, Heart, Share2, ShoppingCart, Plus, Minus, Truck, Shield, RotateCcw, Clock } from 'lucide-react';
import { useCart } from '../context/CartContext';

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { dispatch } = useCart();
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState('256GB');
  const [isWishlisted, setIsWishlisted] = useState(false);

  // Mock product data
  const product = {
    id: '1',
    name: 'Samsung Galaxy S24 Ultra 5G',
    description: 'Experience the ultimate in mobile technology with the Samsung Galaxy S24 Ultra 5G. Featuring a stunning 6.8-inch Dynamic AMOLED 2X display, powerful Snapdragon 8 Gen 3 processor, and revolutionary AI-powered camera system.',
    price: 124999,
    originalPrice: 139999,
    discount: 11,
    rating: 4.5,
    reviews: 12453,
    images: [
      'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg',
      'https://images.pexels.com/photos/699122/pexels-photo-699122.jpeg',
      'https://images.pexels.com/photos/163065/mobile-phone-android-apps-phone-163065.jpeg',
      'https://images.pexels.com/photos/1616470/pexels-photo-1616470.jpeg',
    ],
    variants: ['128GB', '256GB', '512GB', '1TB'],
    colors: ['Titanium Gray', 'Titanium Black', 'Titanium Violet', 'Titanium Yellow'],
    specifications: {
      'Display': '6.8" Dynamic AMOLED 2X, 120Hz',
      'Processor': 'Snapdragon 8 Gen 3',
      'RAM': '12GB',
      'Storage': '256GB',
      'Camera': '200MP + 50MP + 10MP + 12MP',
      'Battery': '5000mAh',
      'OS': 'Android 14, One UI 6.1',
    },
    features: [
      'S Pen included',
      '200MP camera with AI enhancement',
      '5G connectivity',
      'Wireless charging',
      'Water resistant IP68',
    ],
    inStock: true,
    deliveryTime: 'Tomorrow by 10 AM',
    returnPolicy: '7 days return policy',
    warranty: '1 year manufacturer warranty',
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const handleAddToCart = () => {
    dispatch({
      type: 'ADD_ITEM',
      payload: {
        id: product.id,
        name: `${product.name} (${selectedVariant})`,
        price: product.price,
        originalPrice: product.originalPrice,
        image: product.images[0],
        quantity: quantity,
        category: 'electronics',
      }
    });
  };

  const reviews = [
    {
      id: 1,
      user: 'Rahul Kumar',
      rating: 5,
      date: '15 Nov 2024',
      comment: 'Excellent phone! Camera quality is outstanding and performance is top-notch.',
      helpful: 23,
    },
    {
      id: 2,
      user: 'Priya Sharma',
      rating: 4,
      date: '12 Nov 2024',
      comment: 'Good build quality and fast delivery. Battery life could be better.',
      helpful: 18,
    },
    {
      id: 3,
      user: 'Amit Patel',
      rating: 5,
      date: '10 Nov 2024',
      comment: 'Worth every penny! The S Pen functionality is amazing.',
      helpful: 31,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="bg-white rounded-lg shadow-md p-4">
              <img
                src={product.images[selectedImage]}
                alt={product.name}
                className="w-full h-96 object-cover rounded-lg"
              />
            </div>
            <div className="grid grid-cols-4 gap-2">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`border-2 rounded-lg overflow-hidden ${
                    selectedImage === index ? 'border-blue-500' : 'border-gray-200'
                  }`}
                >
                  <img
                    src={image}
                    alt={`${product.name} ${index + 1}`}
                    className="w-full h-20 object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="mb-4">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">{product.name}</h1>
              <div className="flex items-center space-x-4 mb-4">
                <div className="flex items-center bg-green-500 text-white px-2 py-1 rounded text-sm">
                  <span className="font-semibold mr-1">{product.rating}</span>
                  <Star className="w-4 h-4 fill-current" />
                </div>
                <span className="text-gray-600">
                  {product.reviews.toLocaleString()} reviews
                </span>
              </div>
            </div>

            {/* Price */}
            <div className="mb-6">
              <div className="flex items-center space-x-3 mb-2">
                <span className="text-3xl font-bold text-gray-900">
                  {formatPrice(product.price)}
                </span>
                <span className="text-lg text-gray-500 line-through">
                  {formatPrice(product.originalPrice)}
                </span>
                <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-sm font-semibold">
                  {product.discount}% OFF
                </span>
              </div>
              <p className="text-sm text-gray-600">Inclusive of all taxes</p>
            </div>

            {/* Variants */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3">Storage</h3>
              <div className="flex space-x-2">
                {product.variants.map((variant) => (
                  <button
                    key={variant}
                    onClick={() => setSelectedVariant(variant)}
                    className={`px-4 py-2 border rounded-lg ${
                      selectedVariant === variant
                        ? 'border-blue-500 bg-blue-50 text-blue-600'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    {variant}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3">Quantity</h3>
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 border border-gray-300 rounded-lg flex items-center justify-center hover:bg-gray-50"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-12 text-center font-semibold">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 border border-gray-300 rounded-lg flex items-center justify-center hover:bg-gray-50"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex space-x-4 mb-6">
              <button
                onClick={handleAddToCart}
                className="flex-1 bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-lg font-semibold flex items-center justify-center space-x-2"
              >
                <ShoppingCart className="w-5 h-5" />
                <span>Add to Cart</span>
              </button>
              <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold">
                Buy Now
              </button>
            </div>

            <div className="flex space-x-4 mb-6">
              <button
                onClick={() => setIsWishlisted(!isWishlisted)}
                className={`flex items-center space-x-2 px-4 py-2 border rounded-lg ${
                  isWishlisted ? 'border-red-500 text-red-500' : 'border-gray-300 text-gray-600'
                } hover:bg-gray-50`}
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
                <span>Wishlist</span>
              </button>
              <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50">
                <Share2 className="w-4 h-4" />
                <span>Share</span>
              </button>
            </div>

            {/* Delivery Info */}
            <div className="border-t pt-4">
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Truck className="w-5 h-5 text-green-600" />
                  <div>
                    <span className="font-semibold">Free Delivery</span>
                    <p className="text-sm text-gray-600">{product.deliveryTime}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <RotateCcw className="w-5 h-5 text-blue-600" />
                  <div>
                    <span className="font-semibold">Easy Returns</span>
                    <p className="text-sm text-gray-600">{product.returnPolicy}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Shield className="w-5 h-5 text-purple-600" />
                  <div>
                    <span className="font-semibold">Warranty</span>
                    <p className="text-sm text-gray-600">{product.warranty}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="border-b border-gray-200 mb-6">
            <nav className="-mb-px flex space-x-8">
              <button className="border-b-2 border-blue-500 text-blue-600 py-2 px-1 font-semibold">
                Description
              </button>
              <button className="text-gray-500 hover:text-gray-700 py-2 px-1">
                Specifications
              </button>
              <button className="text-gray-500 hover:text-gray-700 py-2 px-1">
                Reviews
              </button>
            </nav>
          </div>

          {/* Description */}
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-3">Product Description</h3>
              <p className="text-gray-700 leading-relaxed">{product.description}</p>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-3">Key Features</h3>
              <ul className="space-y-2">
                {product.features.map((feature, index) => (
                  <li key={index} className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Reviews */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-6">Customer Reviews</h3>
          <div className="space-y-6">
            {reviews.map((review) => (
              <div key={review.id} className="border-b border-gray-200 pb-6 last:border-b-0">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
                    <span className="text-sm font-semibold">
                      {review.user.charAt(0)}
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="font-semibold">{review.user}</span>
                      <div className="flex items-center bg-green-500 text-white px-2 py-1 rounded text-xs">
                        <span className="mr-1">{review.rating}</span>
                        <Star className="w-3 h-3 fill-current" />
                      </div>
                      <span className="text-sm text-gray-500">{review.date}</span>
                    </div>
                    <p className="text-gray-700 mb-2">{review.comment}</p>
                    <button className="text-sm text-gray-500 hover:text-gray-700">
                      👍 Helpful ({review.helpful})
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;