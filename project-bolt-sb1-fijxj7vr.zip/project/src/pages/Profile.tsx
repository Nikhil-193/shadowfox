import React, { useState } from 'react';
import { User, MapPin, ShoppingBag, Heart, Settings, LogOut, Edit, Plus } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Profile = () => {
  const { authState, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');

  const menuItems = [
    { id: 'profile', label: 'Profile Information', icon: User },
    { id: 'addresses', label: 'Manage Addresses', icon: MapPin },
    { id: 'orders', label: 'My Orders', icon: ShoppingBag },
    { id: 'wishlist', label: 'My Wishlist', icon: Heart },
    { id: 'settings', label: 'Account Settings', icon: Settings },
  ];

  const orders = [
    {
      id: 'ORD001',
      date: '2024-11-15',
      status: 'Delivered',
      total: 124999,
      items: 1,
      image: 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg',
    },
    {
      id: 'ORD002',
      date: '2024-11-12',
      status: 'In Transit',
      total: 7495,
      items: 2,
      image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg',
    },
  ];

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Delivered': return 'text-green-600 bg-green-50';
      case 'In Transit': return 'text-blue-600 bg-blue-50';
      case 'Processing': return 'text-orange-600 bg-orange-50';
      case 'Cancelled': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const renderProfileInfo = () => (
    <div className="space-y-6">
      <div className="flex items-center space-x-6">
        <div className="w-24 h-24 bg-blue-600 text-white rounded-full flex items-center justify-center text-2xl font-bold">
          {authState.user?.name?.charAt(0) || 'U'}
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{authState.user?.name}</h2>
          <p className="text-gray-600">{authState.user?.email}</p>
          <p className="text-gray-600">{authState.user?.phone}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-50 p-4 rounded-lg">
          <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
          <input
            type="text"
            defaultValue={authState.user?.name}
            className="w-full border border-gray-300 rounded-lg px-3 py-2"
          />
        </div>
        <div className="bg-gray-50 p-4 rounded-lg">
          <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
          <input
            type="email"
            defaultValue={authState.user?.email}
            className="w-full border border-gray-300 rounded-lg px-3 py-2"
          />
        </div>
        <div className="bg-gray-50 p-4 rounded-lg">
          <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
          <input
            type="tel"
            defaultValue={authState.user?.phone}
            className="w-full border border-gray-300 rounded-lg px-3 py-2"
          />
        </div>
        <div className="bg-gray-50 p-4 rounded-lg">
          <label className="block text-sm font-medium text-gray-700 mb-1">Date of Birth</label>
          <input
            type="date"
            className="w-full border border-gray-300 rounded-lg px-3 py-2"
          />
        </div>
      </div>

      <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg">
        Update Profile
      </button>
    </div>
  );

  const renderAddresses = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Saved Addresses</h3>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2">
          <Plus className="w-4 h-4" />
          <span>Add New Address</span>
        </button>
      </div>

      {authState.user?.addresses?.map((address) => (
        <div key={address.id} className="bg-gray-50 p-4 rounded-lg">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <span className="font-semibold">{address.name}</span>
                <span className="bg-gray-200 text-gray-600 px-2 py-1 rounded text-xs uppercase">
                  {address.type}
                </span>
              </div>
              <p className="text-gray-700 mb-1">{address.address}</p>
              <p className="text-gray-700 mb-1">{address.city}, {address.state} - {address.pincode}</p>
              <p className="text-gray-600 text-sm">{address.phone}</p>
            </div>
            <button className="text-blue-600 hover:text-blue-700">
              <Edit className="w-4 h-4" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );

  const renderOrders = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Order History</h3>
      
      {orders.map((order) => (
        <div key={order.id} className="bg-gray-50 p-4 rounded-lg">
          <div className="flex items-center space-x-4">
            <img
              src={order.image}
              alt="Order"
              className="w-16 h-16 object-cover rounded-lg"
            />
            <div className="flex-1">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-semibold">Order #{order.id}</h4>
                  <p className="text-sm text-gray-600">
                    {new Date(order.date).toLocaleDateString('en-IN')} • {order.items} item(s)
                  </p>
                </div>
                <div className="text-right">
                  <div className="font-semibold">{formatPrice(order.total)}</div>
                  <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                    {order.status}
                  </span>
                </div>
              </div>
              <div className="flex space-x-2">
                <button className="text-blue-600 hover:text-blue-700 text-sm">
                  View Details
                </button>
                {order.status === 'Delivered' && (
                  <>
                    <span className="text-gray-400">|</span>
                    <button className="text-blue-600 hover:text-blue-700 text-sm">
                      Reorder
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold">Account Settings</h3>
      
      <div className="space-y-4">
        <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
          <div>
            <h4 className="font-medium">Email Notifications</h4>
            <p className="text-sm text-gray-600">Receive order updates and promotions</p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" defaultChecked className="sr-only peer" />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        </div>

        <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
          <div>
            <h4 className="font-medium">SMS Notifications</h4>
            <p className="text-sm text-gray-600">Receive delivery updates via SMS</p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" defaultChecked className="sr-only peer" />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        </div>

        <div className="p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium mb-2">Change Password</h4>
          <div className="space-y-3">
            <input
              type="password"
              placeholder="Current Password"
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            />
            <input
              type="password"
              placeholder="New Password"
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            />
            <input
              type="password"
              placeholder="Confirm New Password"
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            />
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
              Update Password
            </button>
          </div>
        </div>

        <div className="p-4 bg-red-50 rounded-lg border border-red-200">
          <h4 className="font-medium text-red-800 mb-2">Danger Zone</h4>
          <p className="text-sm text-red-600 mb-3">
            Once you delete your account, there is no going back. Please be certain.
          </p>
          <button className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg">
            Delete Account
          </button>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'profile': return renderProfileInfo();
      case 'addresses': return renderAddresses();
      case 'orders': return renderOrders();
      case 'wishlist': return (
        <div className="text-center py-12">
          <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Your wishlist is empty</h3>
          <p className="text-gray-600">Add items to your wishlist to save them for later</p>
        </div>
      );
      case 'settings': return renderSettings();
      default: return renderProfileInfo();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-2">
                  {authState.user?.name?.charAt(0) || 'U'}
                </div>
                <h3 className="font-semibold">{authState.user?.name}</h3>
                <p className="text-sm text-gray-600">{authState.user?.email}</p>
              </div>

              <nav className="space-y-2">
                {menuItems.map((item) => {
                  const IconComponent = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                        activeTab === item.id
                          ? 'bg-blue-50 text-blue-600 border-r-2 border-blue-600'
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <IconComponent className="w-5 h-5" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
                
                <button
                  onClick={logout}
                  className="w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left text-red-600 hover:bg-red-50 transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </button>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow-md p-6">
              {renderContent()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;