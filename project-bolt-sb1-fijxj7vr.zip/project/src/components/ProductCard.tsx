import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Clock, Truck } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  discount: number;
  rating: number;
  reviews: number;
  image: string;
  category: string;
  isInstantDelivery?: boolean;
  deliveryTime?: string;
}

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <Link to={`/product/${product.id}`}>
      <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-4 border border-gray-200">
        {/* Product Image */}
        <div className="relative mb-3">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-48 object-cover rounded-lg"
          />
          {product.discount > 0 && (
            <div className="absolute top-2 left-2 bg-green-500 text-white px-2 py-1 rounded text-xs font-semibold">
              {product.discount}% OFF
            </div>
          )}
          {product.isInstantDelivery && (
            <div className="absolute top-2 right-2 bg-orange-500 text-white px-2 py-1 rounded text-xs font-semibold flex items-center">
              <Clock className="w-3 h-3 mr-1" />
              INSTANT
            </div>
          )}
        </div>

        {/* Product Info */}
        <div>
          <h3 className="text-sm font-medium text-gray-900 mb-2 line-clamp-2">
            {product.name}
          </h3>

          {/* Rating */}
          <div className="flex items-center mb-2">
            <div className="flex items-center bg-green-500 text-white px-2 py-1 rounded text-xs">
              <span className="font-semibold mr-1">{product.rating}</span>
              <Star className="w-3 h-3 fill-current" />
            </div>
            <span className="text-gray-500 text-xs ml-2">
              ({product.reviews.toLocaleString()})
            </span>
          </div>

          {/* Price */}
          <div className="flex items-center space-x-2 mb-2">
            <span className="text-lg font-bold text-gray-900">
              {formatPrice(product.price)}
            </span>
            {product.originalPrice > product.price && (
              <span className="text-sm text-gray-500 line-through">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>

          {/* Delivery Info */}
          <div className="flex items-center text-xs text-gray-600">
            <Truck className="w-3 h-3 mr-1" />
            {product.isInstantDelivery ? (
              <span className="text-orange-600 font-semibold">
                {product.deliveryTime || 'Within 30 mins'}
              </span>
            ) : (
              <span>Free delivery</span>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;