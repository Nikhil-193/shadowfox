import React from 'react';
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About */}
          <div>
            <h3 className="text-lg font-semibold mb-4">ABOUT</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white">Contact Us</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">About Us</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Careers</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">FlipMart Stories</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Press</a></li>
            </ul>
          </div>

          {/* Help */}
          <div>
            <h3 className="text-lg font-semibold mb-4">HELP</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white">Payments</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Shipping</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Cancellation & Returns</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">FAQ</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Report Infringement</a></li>
            </ul>
          </div>

          {/* Policy */}
          <div>
            <h3 className="text-lg font-semibold mb-4">POLICY</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white">Return Policy</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Terms Of Use</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Security</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Privacy</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Sitemap</a></li>
            </ul>
          </div>

          {/* Social & Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">SOCIAL</h3>
            <div className="flex space-x-4 mb-6">
              <Facebook className="w-6 h-6 text-gray-300 hover:text-white cursor-pointer" />
              <Twitter className="w-6 h-6 text-gray-300 hover:text-white cursor-pointer" />
              <Instagram className="w-6 h-6 text-gray-300 hover:text-white cursor-pointer" />
              <Youtube className="w-6 h-6 text-gray-300 hover:text-white cursor-pointer" />
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span className="text-gray-300">support@flipmart.com</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span className="text-gray-300">1800-123-4567</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-4 mb-4 md:mb-0">
            <span className="text-gray-300">Payment Methods:</span>
            <div className="flex space-x-2">
              <div className="bg-white text-black px-2 py-1 rounded text-xs font-semibold">UPI</div>
              <div className="bg-white text-black px-2 py-1 rounded text-xs font-semibold">CARD</div>
              <div className="bg-white text-black px-2 py-1 rounded text-xs font-semibold">COD</div>
            </div>
          </div>
          <div className="text-gray-300 text-sm">
            © 2024 FlipMart. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;