import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { BookOpen, Award, Briefcase } from 'lucide-react';

const About = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6
      }
    }
  };

  const educationItems = [
    {
      institution: "Don Bosco High School",
      year: "2020",
      description: "Passed with 82%"
    },
    {
      institution: "Sri Chaitanya Junior College",
      year: "2022",
      description: "Passed with ~65%"
    },
    {
      institution: "BEST COMPUTERS",
      year: "2022-2023",
      description: "Long-term upskilling and technical training in programming and design tools"
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="space-y-12"
        >
          <motion.div variants={itemVariants} className="text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800">
              About <span className="text-purple-600">Me</span>
            </h2>
            <div className="w-20 h-1 bg-purple-600 mx-auto mt-4 rounded-full"></div>
          </motion.div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <motion.div 
              variants={itemVariants} 
              className="md:col-span-2 bg-gray-50 p-8 rounded-xl shadow-sm"
            >
              <h3 className="text-xl font-semibold text-gray-800 mb-4">
                My Story
              </h3>
              <div className="space-y-4 text-gray-600">
                <p>
                  I'm Hema Satya Nikhil, a creative and technically skilled Graphic Designer and Content Creator with over 2 years of hands-on experience in design and development. I began my journey during a long-term gap after intermediate studies, using that time to explore and master tools that help bring ideas to life.
                </p>
                <p>
                  I'm certified in industry-standard software like Adobe Photoshop, Premiere Pro, After Effects, and Blender. I've completed freelance work on Fiverr, including movie poster designs and YouTube thumbnails. My strong technical foundation includes programming in C, C++, HTML, CSS, and JavaScript. I'm driven by curiosity, quick at debugging, and thrive on balancing logic and creativity.
                </p>
                <p>
                  I also completed an internship at <strong>ShadowFox Web Development</strong>, gaining hands-on experience in real-world project environments.
                </p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="space-y-8">
              <div className="bg-gray-50 p-6 rounded-xl shadow-sm">
                <div className="flex items-center mb-4">
                  <div className="p-2 bg-purple-100 rounded-lg mr-4">
                    <BookOpen className="text-purple-600" size={24} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800">Education</h3>
                </div>
                <div className="space-y-4">
                  {educationItems.map((item, index) => (
                    <div key={index} className="border-l-2 border-purple-200 pl-4 py-1">
                      <h4 className="font-medium text-gray-800">{item.institution}</h4>
                      <p className="text-sm text-gray-500">{item.year}</p>
                      <p className="text-sm text-gray-600">{item.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex space-x-4">
                <motion.div 
                  className="flex-1 bg-purple-600 p-4 rounded-xl text-white text-center shadow-sm"
                  whileHover={{ scale: 1.05 }}
                >
                  <Award size={28} className="mx-auto mb-2" />
                  <p className="font-medium">Certified Designer</p>
                </motion.div>
                <motion.div 
                  className="flex-1 bg-purple-600 p-4 rounded-xl text-white text-center shadow-sm"
                  whileHover={{ scale: 1.05 }}
                >
                  <Briefcase size={28} className="mx-auto mb-2" />
                  <p className="font-medium">Freelancer</p>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;