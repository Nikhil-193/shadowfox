import React from 'react';
import { motion } from 'framer-motion';
import { Github, Linkedin, Instagram, Mail, Heart } from 'lucide-react';

const Footer = () => {
  const socialLinks = [
    { icon: <Github size={18} />, url: 'https://github.com/Nikhil-193' },
    { icon: <Linkedin size={18} />, url: 'https://www.linkedin.com/in/hema-satya-nikhil-964313320' },
    { icon: <Instagram size={18} />, url: 'https://www.instagram.com/unknown_person_nikhil' },
    { icon: <Mail size={18} />, url: 'mailto:satyanikhil24@gmail.com' },
  ];

  const footerLinks = [
    { text: 'Home', url: '#home' },
    { text: 'About', url: '#about' },
    { text: 'Skills', url: '#skills' },
    { text: 'Portfolio', url: '#portfolio' },
    { text: 'Experience', url: '#experience' },
    { text: 'Contact', url: '#contact' },
  ];

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <motion.a 
              href="#home" 
              className="text-2xl font-bold text-purple-400 inline-block mb-4"
              whileHover={{ scale: 1.05 }}
            >
              NIKHIL
            </motion.a>
            <p className="text-gray-400 mb-4 max-w-xs">
              Graphic Designer & Front-End Developer with a passion for creating beautiful and functional digital experiences.
            </p>
            <div className="flex space-x-3">
              {socialLinks.map((link, index) => (
                <motion.a
                  key={index}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-gray-800 hover:bg-purple-600 rounded-full transition-colors"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  whileTap={{ scale: 0.9 }}
                >
                  {link.icon}
                </motion.a>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {footerLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.url} 
                    className="text-gray-400 hover:text-purple-400 transition-colors"
                  >
                    {link.text}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <p className="text-gray-400 mb-2">
              Hyderabad, India
            </p>
            <p className="text-gray-400 mb-2">
              satyanikhil24@gmail.com
            </p>
            <p className="text-gray-400">
              +91 1234567890
            </p>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 text-center">
          <p className="text-gray-400 flex items-center justify-center">
            © {new Date().getFullYear()} Hema Satya Nikhil. All rights reserved. Made with 
            <Heart size={16} className="text-red-500 mx-1" fill="currentColor" /> 
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;