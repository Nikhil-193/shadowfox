import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight, Github, Linkedin, Instagram, Mail } from 'lucide-react';

const Hero = () => {
  const heroVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delay: 0.2,
        staggerChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  const socialLinks = [
    { icon: <Github size={20} />, url: 'https://github.com/Nikhil-193' },
    { icon: <Linkedin size={20} />, url: 'https://www.linkedin.com/in/hema-satya-nikhil-964313320' },
    { icon: <Instagram size={20} />, url: 'https://www.instagram.com/unknown_person_nikhil' },
    { icon: <Mail size={20} />, url: 'mailto:satyanikhil24@gmail.com' },
  ];

  return (
    <section id="home" className="min-h-screen pt-20 bg-gradient-to-br from-white to-purple-50">
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-20 md:py-32 flex flex-col md:flex-row items-center justify-between">
        <motion.div
          className="md:w-1/2 mb-12 md:mb-0"
          variants={heroVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div variants={itemVariants}>
            <div className="inline-block px-4 py-1 bg-purple-100 text-purple-700 rounded-full mb-4">
              Graphic Designer & Front-End Developer
            </div>
          </motion.div>
          
          <motion.h1 
            variants={itemVariants} 
            className="text-4xl md:text-6xl font-bold text-gray-800 mb-4"
          >
            Hi, I'm <span className="text-purple-700">Hema Satya Nikhil</span>
          </motion.h1>
          
          <motion.p 
            variants={itemVariants}
            className="text-lg text-gray-600 mb-8 max-w-lg"
          >
            Creative and technically skilled professional blending design, development, and client collaboration.
          </motion.p>
          
          <motion.div 
            variants={itemVariants}
            className="flex flex-wrap gap-4"
          >
            <motion.a
              href="#portfolio"
              className="px-6 py-3 bg-purple-600 text-white rounded-md flex items-center gap-2 hover:bg-purple-700 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              View Projects
              <ChevronRight size={18} />
            </motion.a>
            <motion.a
              href="#contact"
              className="px-6 py-3 border-2 border-purple-600 text-purple-600 rounded-md hover:bg-purple-50 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Contact Me
            </motion.a>
          </motion.div>
          
          <motion.div 
            variants={itemVariants}
            className="flex gap-4 mt-8"
          >
            {socialLinks.map((link, index) => (
              <motion.a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 bg-gray-100 text-gray-700 rounded-full hover:bg-purple-100 hover:text-purple-600 transition-colors"
                whileHover={{ scale: 1.1, rotate: 5 }}
                whileTap={{ scale: 0.9 }}
              >
                {link.icon}
              </motion.a>
            ))}
          </motion.div>
        </motion.div>
        
        <motion.div
          className="md:w-1/2 flex justify-center"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <div className="relative w-64 h-64 md:w-96 md:h-96">
            <div className="absolute inset-0 bg-purple-600 rounded-full opacity-20 blur-xl transform -translate-x-4 translate-y-4"></div>
            <div className="absolute inset-0 border-2 border-purple-400 rounded-full transform translate-x-4 -translate-y-4"></div>
            <img 
              src="https://i.postimg.cc/d1fx1hmH/Firefly-20250114183757.png" 
              alt="Hema Satya Nikhil Profile" 
              className="rounded-full w-full h-full object-cover border-4 border-white shadow-xl"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;