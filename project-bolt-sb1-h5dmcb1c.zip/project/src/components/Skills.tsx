import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Palette, Code, UserPlus } from 'lucide-react';

const Skills = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  const designSkills = [
    { name: 'Photoshop', level: 90 },
    { name: 'Premiere Pro', level: 85 },
    { name: 'After Effects', level: 80 },
    { name: 'Blender', level: 75 },
    { name: 'Canva', level: 95 },
    { name: 'CapCut', level: 90 },
    { name: 'Figma', level: 65 },
  ];

  const devSkills = [
    { name: 'HTML', level: 90 },
    { name: 'CSS', level: 85 },
    { name: 'JavaScript', level: 80 },
    { name: 'C', level: 75 },
    { name: 'C++', level: 70 },
  ];

  const personalSkills = [
    { name: 'Fast Learner', level: 95 },
    { name: 'Communication', level: 90 },
    { name: 'Client Interaction', level: 85 },
    { name: 'Debugging', level: 90 },
    { name: 'Problem Solving', level: 85 },
  ];

  const SkillBar = ({ name, level }) => (
    <motion.div 
      className="mb-4"
      variants={itemVariants}
    >
      <div className="flex justify-between mb-1">
        <span className="text-gray-700 font-medium">{name}</span>
        <span className="text-gray-500 text-sm">{level}%</span>
      </div>
      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
        <motion.div 
          className="h-full bg-purple-600 rounded-full"
          initial={{ width: 0 }}
          animate={inView ? { width: `${level}%` } : { width: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
        ></motion.div>
      </div>
    </motion.div>
  );

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="space-y-12"
        >
          <motion.div variants={itemVariants} className="text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800">
              My <span className="text-purple-600">Skills</span>
            </h2>
            <div className="w-20 h-1 bg-purple-600 mx-auto mt-4 rounded-full"></div>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            <motion.div 
              variants={itemVariants}
              className="bg-white p-6 rounded-xl shadow-sm"
            >
              <div className="flex items-center mb-6">
                <div className="p-2 bg-purple-100 rounded-lg mr-4">
                  <Palette className="text-purple-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-800">Design & Media Tools</h3>
              </div>
              <div>
                {designSkills.map((skill, index) => (
                  <SkillBar key={index} name={skill.name} level={skill.level} />
                ))}
              </div>
            </motion.div>

            <motion.div 
              variants={itemVariants}
              className="bg-white p-6 rounded-xl shadow-sm"
            >
              <div className="flex items-center mb-6">
                <div className="p-2 bg-purple-100 rounded-lg mr-4">
                  <Code className="text-purple-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-800">Development</h3>
              </div>
              <div>
                {devSkills.map((skill, index) => (
                  <SkillBar key={index} name={skill.name} level={skill.level} />
                ))}
              </div>
            </motion.div>

            <motion.div 
              variants={itemVariants}
              className="bg-white p-6 rounded-xl shadow-sm"
            >
              <div className="flex items-center mb-6">
                <div className="p-2 bg-purple-100 rounded-lg mr-4">
                  <UserPlus className="text-purple-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold text-gray-800">Personal Strengths</h3>
              </div>
              <div>
                {personalSkills.map((skill, index) => (
                  <SkillBar key={index} name={skill.name} level={skill.level} />
                ))}
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;