import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ExternalLink } from 'lucide-react';

const Portfolio = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const [activeProject, setActiveProject] = useState(null);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  const projects = [
    {
      id: 2,
      title: 'Wi-Fi Protecting Device',
      category: 'Hackathon Project',
      description: 'Developed a Wi-Fi protecting device using NodeMCU ESP during a 48-hour hackathon. The device monitors network traffic and alerts users of potential security breaches.',
      image: 'https://i.postimg.cc/4NLLJLsf/photo-2025-06-03-16-37-11.jpg',
      link: '#'
    }
  ];

  const openProject = (project) => {
    setActiveProject(project);
  };

  const closeProject = () => {
    setActiveProject(null);
  };

  return (
    <section id="portfolio" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="space-y-12"
        >
          <motion.div variants={itemVariants} className="text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800">
              My <span className="text-purple-600">Portfolio</span>
            </h2>
            <div className="w-20 h-1 bg-purple-600 mx-auto mt-4 rounded-full"></div>
            <p className="mt-4 text-gray-600 max-w-xl mx-auto">
              A selection of my recent works spanning graphic design, development, and content creation.
            </p>
          </motion.div>

          <motion.div 
            variants={containerVariants}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {projects.map((project) => (
              <motion.div
                key={project.id}
                variants={itemVariants}
                whileHover={{ y: -10 }}
                className="bg-gray-50 rounded-xl overflow-hidden shadow-sm group cursor-pointer"
                onClick={() => openProject(project)}
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-xs text-purple-600 font-medium uppercase tracking-wider">
                        {project.category}
                      </span>
                      <h3 className="text-lg font-semibold text-gray-800 mt-1">{project.title}</h3>
                    </div>
                    <div className="p-2 bg-purple-100 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                      <ExternalLink size={16} className="text-purple-600" />
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Project Modal */}
      {activeProject && (
        <motion.div 
          className="fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={closeProject}
        >
          <motion.div 
            className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-auto"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
          >
            <img 
              src={activeProject.image} 
              alt={activeProject.title} 
              className="w-full h-64 object-cover"
            />
            <div className="p-8">
              <span className="text-sm text-purple-600 font-medium uppercase tracking-wider">
                {activeProject.category}
              </span>
              <h2 className="text-2xl font-bold text-gray-800 mt-2 mb-4">{activeProject.title}</h2>
              <p className="text-gray-600 mb-6">{activeProject.description}</p>
              <div className="flex justify-between items-center">
                <button 
                  onClick={closeProject}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Close
                </button>
                <a 
                  href={activeProject.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 flex items-center gap-2"
                >
                  View Project
                  <ExternalLink size={16} />
                </a>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </section>
  );
};

export default Portfolio;