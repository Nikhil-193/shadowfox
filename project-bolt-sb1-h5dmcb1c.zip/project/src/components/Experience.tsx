import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Briefcase, Calendar, Building, Users } from 'lucide-react';

const Experience = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6
      }
    }
  };

  const experiences = [
    {
      title: "Web Development Intern",
      company: "ShadowFox Web Development",
      period: "2025 - Present",
      description: "Gained real-world exposure to website development, code versioning, UI/UX collaboration, and project communication. Worked directly with senior developers to implement responsive designs and participate in client feedback sessions.",
      skills: ["HTML/CSS", "JavaScript", "Git", "UI/UX", "Communication"],
      icon: <Building />
    },
    {
      title: "Freelance Graphic Designer",
      company: "Fiverr",
      period: "2023",
      description: "Worked with 2–3 clients, delivered quality visuals, handled feedback loops, and built strong communication skills. Specialized in creating movie posters, YouTube thumbnails, and social media graphics for various clients globally.",
      skills: ["Photoshop", "Design", "Client Management", "Deadlines", "Branding"],
      icon: <Users />
    }
  ];

  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="space-y-12"
        >
          <motion.div variants={itemVariants} className="text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800">
              Work <span className="text-purple-600">Experience</span>
            </h2>
            <div className="w-20 h-1 bg-purple-600 mx-auto mt-4 rounded-full"></div>
          </motion.div>
          
          <div className="relative">
            {/* Timeline line */}
            <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-purple-200"></div>
            
            {/* Experience items */}
            {experiences.map((exp, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className={`md:flex items-center mb-12 ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                {/* Timeline dot */}
                <div className="hidden md:flex absolute left-1/2 transform -translate-x-1/2 items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center text-white z-10">
                    {exp.icon}
                  </div>
                </div>

                {/* Content */}
                <div className={`md:w-1/2 ${index % 2 === 0 ? 'md:pr-16' : 'md:pl-16'}`}>
                  <div className="bg-white p-6 rounded-xl shadow-sm">
                    <div className="flex md:hidden items-center mb-4">
                      <div className="p-2 bg-purple-100 rounded-lg mr-3">
                        {exp.icon}
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-gray-800">{exp.title}</h3>
                        <p className="text-gray-600">{exp.company}</p>
                      </div>
                    </div>
                    
                    <div className="hidden md:block">
                      <h3 className="text-xl font-semibold text-gray-800">{exp.title}</h3>
                      <p className="text-gray-600 mb-1">{exp.company}</p>
                    </div>
                    
                    <div className="flex items-center text-sm text-purple-600 mb-4">
                      <Calendar size={16} className="mr-2" />
                      <span>{exp.period}</span>
                    </div>
                    
                    <p className="text-gray-600 mb-4">{exp.description}</p>
                    
                    <div className="flex flex-wrap gap-2">
                      {exp.skills.map((skill, i) => (
                        <span 
                          key={i} 
                          className="px-3 py-1 bg-purple-50 text-purple-600 text-xs font-medium rounded-full"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                
                {/* Empty div to maintain layout */}
                <div className="hidden md:block md:w-1/2"></div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Experience;